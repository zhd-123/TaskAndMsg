﻿// updfShellEx.cpp: DLL 导出的实现。


#include "pch.h"
#include "framework.h"
#include "resource.h"
#include "updfShellEx_i.h"
#include "dllmain.h"

#pragma warning(disable: 4996)
using namespace ATL;

// 用于确定 DLL 是否可由 OLE 卸载。
_Use_decl_annotations_
STDAPI DllCanUnloadNow(void)
{
	return _AtlModule.DllCanUnloadNow();
}

// 返回一个类工厂以创建所请求类型的对象。
_Use_decl_annotations_
STDAPI DllGetClassObject(_In_ REFCLSID rclsid, _In_ REFIID riid, _Outptr_ LPVOID* ppv)
{
	return _AtlModule.DllGetClassObject(rclsid, riid, ppv);
}

// DllRegisterServer - 向系统注册表中添加项。
_Use_decl_annotations_
STDAPI DllRegisterServer(void)
{
	// 注册对象、类型库和类型库中的所有接口
	if (0 == (GetVersion() & 0x80000000UL))
	{
		CRegKey reg;
		LONG    lRet;

		lRet = reg.Open(HKEY_LOCAL_MACHINE,
			_T("Software\\Microsoft\\Windows\\CurrentVersion\\Shell Extensions\\Approved"),
			KEY_SET_VALUE);

		if (ERROR_SUCCESS != lRet)
			return E_ACCESSDENIED;

		lRet = reg.SetStringValue(_T("{792c32d2-8e86-482a-92e0-1e8340d0441e}"), _T("UPDF.ContextMenu"));
		if (ERROR_SUCCESS != lRet)
			return E_ACCESSDENIED;

		lRet = reg.Create(HKEY_CLASSES_ROOT, _T("*\\shellex\\ContextMenuHandlers\\UPDF.ContextMenu"));
		if (ERROR_SUCCESS != lRet)
			return E_ACCESSDENIED;
		lRet = reg.SetStringValue(NULL, _T("{792c32d2-8e86-482a-92e0-1e8340d0441e}"));
		if (ERROR_SUCCESS != lRet)
			return E_ACCESSDENIED;
	}
	HRESULT hr = _AtlModule.DllRegisterServer();
	return hr;
}

// DllUnregisterServer - 移除系统注册表中的项。
_Use_decl_annotations_
STDAPI DllUnregisterServer(void)
{
	if (0 == (GetVersion() & 0x80000000UL))
	{
		CRegKey reg;
		LONG    lRet;

		lRet = reg.Open(HKEY_LOCAL_MACHINE,
			_T("Software\\Microsoft\\Windows\\CurrentVersion\\Shell Extensions\\Approved"),
			KEY_SET_VALUE);

		if (ERROR_SUCCESS == lRet)
		{
			lRet = reg.DeleteValue(_T("{792c32d2-8e86-482a-92e0-1e8340d0441e}"));
		}
		lRet = RegDeleteKeyW(HKEY_CLASSES_ROOT, _T("*\\shellex\\ContextMenuHandlers\\UPDF.ContextMenu"));
	}

	HRESULT hr = _AtlModule.DllUnregisterServer();
	return hr;
}

// DllInstall - 按用户和计算机在系统注册表中逐一添加/移除项。
STDAPI DllInstall(BOOL bInstall, _In_opt_  LPCWSTR pszCmdLine)
{
	HRESULT hr = E_FAIL;
	static const wchar_t szUserSwitch[] = L"user";

	if (pszCmdLine != nullptr)
	{
		if (_wcsnicmp(pszCmdLine, szUserSwitch, _countof(szUserSwitch)) == 0)
		{
			ATL::AtlSetPerUserRegistration(true);
		}
	}

	if (bInstall)
	{
		hr = DllRegisterServer();
		if (FAILED(hr))
		{
			DllUnregisterServer();
		}
	}
	else
	{
		hr = DllUnregisterServer();
	}

	return hr;
}


