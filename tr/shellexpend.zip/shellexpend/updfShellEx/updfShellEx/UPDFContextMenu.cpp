﻿// UPDFContextMenu.cpp: CUPDFContextMenu 的实现

#include "pch.h"
#include "UPDFContextMenu.h"

#include "atlconv.h"
#include "Resource.h"
// CUPDFContextMenu

std::wstring GetString(LPCSTR strSection, LPCSTR szName, LPCSTR iniPath);
std::string UTF8ToAnsi(const char* strSrc);
std::string UnicodeToAnsi(const WCHAR* strSrc);
std::wstring UTF8ToUnicode(const char* strSrc);
////////////////
std::wstring ReadReg(HKEY key, LPCWSTR subPath, LPCWSTR subKey);
////////////////
std::string getKeyValue(std::string sKey, int iValue);
std::string getKeyValue(std::string sKey, float fValue);
std::string getKeyValue(std::string sKey, std::string sValue);
std::string getKeyValueArray(std::string sKey, std::string sArray);

HRESULT CUPDFContextMenu::Initialize(LPCITEMIDLIST pidlFolder, LPDATAOBJECT pDataObj, HKEY hProgID)
{
	FORMATETC fmt = { CF_HDROP, NULL, DVASPECT_CONTENT, -1, TYMED_HGLOBAL };
	STGMEDIUM stg = { TYMED_HGLOBAL };
	HDROP hDrop;
	// 在数据对象内查找 CF_HDROP 型数据. 
	if (FAILED(pDataObj->GetData(&fmt, &stg)))
	{
		// Nope! Return an "invalid argument" error back to Explorer.
		return E_INVALIDARG;
	}

	// 获得指向实际数据的指针
	hDrop = (HDROP)GlobalLock(stg.hGlobal);
	// 检查非NULL. 
	if (NULL == hDrop)
	{
		return E_INVALIDARG;
	}

	// 有效性检查 – 保证最少有一个文件名. 
	UINT uNumFiles = DragQueryFile(hDrop, 0xFFFFFFFF, NULL, 0);
	if (0 == uNumFiles)
	{
		GlobalUnlock(stg.hGlobal);
		ReleaseStgMedium(&stg);
		return E_INVALIDARG;
	}

	HRESULT hr = E_INVALIDARG;
	WCHAR wcFileName[MAX_PATH];
	for (UINT i = 0; i < uNumFiles; i++)
	{
		memset(wcFileName, 0, MAX_PATH);
		if (0 == DragQueryFileW(hDrop, i, wcFileName, MAX_PATH))
		{
			break;
		}
		m_filePathVector.push_back(std::wstring(wcFileName));
	}

	if (m_filePathVector.size() > 0) {
		std::wstring path = m_filePathVector.at(0);
		std::wstring suffix = path.substr(path.length() - 4);
		std::wstring suffix1 = path.substr(path.length() - 5);
		if (_wcsicmp(suffix.c_str(), _T(".pdf")) == 0) {
			m_FileType = PDF;
			hr = S_OK;
		}
		else if (_wcsicmp(suffix.c_str(), _T(".doc")) == 0 || _wcsicmp(suffix.c_str(), _T(".xls")) == 0 ||
			_wcsicmp(suffix.c_str(), _T(".ppt")) == 0 || _wcsicmp(suffix.c_str(), _T(".vsd")) == 0 ||
			_wcsicmp(suffix.c_str(), _T(".caj")) == 0 || _wcsicmp(suffix1.c_str(), _T(".docx")) == 0 ||
			_wcsicmp(suffix1.c_str(), _T(".xlsx")) == 0 || _wcsicmp(suffix1.c_str(), _T(".pptx")) == 0 ||
			_wcsicmp(suffix1.c_str(), _T(".vsdx")) == 0) {
			m_FileType = Document;
			hr = S_OK;
		}
		else if (_wcsicmp(suffix.c_str(), _T(".jpg")) == 0 || _wcsicmp(suffix.c_str(), _T(".jpe")) == 0 ||
			_wcsicmp(suffix.c_str(), _T(".png")) == 0 || _wcsicmp(suffix.c_str(), _T(".tif")) == 0 ||
			_wcsicmp(suffix.c_str(), _T(".gif")) == 0 || _wcsicmp(suffix.c_str(), _T(".bmp")) == 0 ||
			_wcsicmp(suffix.c_str(), _T(".svg")) == 0 || _wcsicmp(suffix1.c_str(), _T(".jpeg")) == 0 ||
			_wcsicmp(suffix1.c_str(), _T(".jfif")) == 0 || _wcsicmp(suffix1.c_str(), _T(".tiff")) == 0) {
			m_FileType = Image;
			hr = S_OK;
		}
	}

	GlobalUnlock(stg.hGlobal);
	ReleaseStgMedium(&stg);
	return hr;
}

HRESULT CUPDFContextMenu::QueryContextMenu(HMENU hmenu, UINT uMenuIndex, UINT uidFirstCmd, UINT uidLastCmd, UINT uFlags)
{	
	// 如果标志包含 CMF_DEFAULTONLY 我们不作任何事情. 
	if (uFlags & CMF_DEFAULTONLY)
	{
		return MAKE_HRESULT(SEVERITY_SUCCESS, FACILITY_NULL, 0);
	}
	UINT uCmdID = uidFirstCmd;
	InsertMenu(hmenu, uMenuIndex++, MF_SEPARATOR | MF_BYPOSITION, 0, NULL);

	WCHAR path[MAX_PATH];
	GetModuleFileName(_AtlBaseModule.GetModuleInstance(), path, MAX_PATH);
	std::wstring exeFullPath = std::wstring(path);
	std::wstring dirPath = exeFullPath.substr(0, exeFullPath.find_last_of(_T("\\")));
	std::wstring confPath = dirPath + _T("\\lang\\") + getCurrentLanguage() + _T(".ini");
	std::string langConfPath = UnicodeToAnsi(confPath.c_str());
	UINT uMenuCount = 0;
	if (m_FileType == PDF) {
		if (m_filePathVector.size() > 1) { // 多文件
			InsertMenu(hmenu, uMenuIndex++, MF_BYPOSITION, uCmdID++, GetString("default", "merge_key", langConfPath.c_str()).c_str());
			uMenuCount++;
			if (m_hMenuBmp) {
				SetMenuItemBitmaps(hmenu, uMenuIndex - 1, MF_BYPOSITION, m_hMenuBmp, m_hMenuBmp);
			}
		}
		else {
			InsertMenu(hmenu, uMenuIndex++, MF_BYPOSITION, uCmdID++, GetString("default", "edit_key", langConfPath.c_str()).c_str());
			uMenuCount++;
			if (m_hMenuBmp) {
				SetMenuItemBitmaps(hmenu, uMenuIndex - 1, MF_BYPOSITION, m_hMenuBmp, m_hMenuBmp);
			}
			InsertMenu(hmenu, uMenuIndex++, MF_BYPOSITION, uCmdID++, GetString("default", "print_key", langConfPath.c_str()).c_str());
			uMenuCount++;
			if (m_hMenuBmp) {
				SetMenuItemBitmaps(hmenu, uMenuIndex - 1, MF_BYPOSITION, m_hMenuBmp, m_hMenuBmp);
			}
		}
	}
	else if (m_FileType == Document || m_FileType == Image){
		InsertMenu(hmenu, uMenuIndex++, MF_BYPOSITION, uCmdID++, GetString("default", "convert_key", langConfPath.c_str()).c_str());
		uMenuCount++;
		if (m_hMenuBmp) {
			SetMenuItemBitmaps(hmenu, uMenuIndex - 1, MF_BYPOSITION, m_hMenuBmp, m_hMenuBmp);
		}
	}

	InsertMenu(hmenu, uMenuIndex++, MF_SEPARATOR | MF_BYPOSITION, 0, NULL);

	return MAKE_HRESULT(SEVERITY_SUCCESS, FACILITY_NULL, uMenuCount);
}

HRESULT CUPDFContextMenu::GetCommandString(UINT_PTR idCmd, UINT uFlags, UINT* pwReserved, LPSTR pszName, UINT cchMax)
{
	USES_CONVERSION;
	//检查 idCmd, 它必须是0，因为我们仅有一个添加的菜单项. 
	if (0 != idCmd)
		return E_INVALIDARG;

	// 如果 Explorer 要求帮助字符串，就将它拷贝到提供的缓冲区中. 
	if (uFlags & GCS_HELPTEXT)
	{
		LPCTSTR szText = _T("UPDF Shell Extension");
		if (uFlags & GCS_UNICODE)
		{
			// 我们需要将 pszName 转化为一个 Unicode 字符串, 接着使用Unicode字符串拷贝 API. 
			lstrcpynW((LPWSTR)pszName, T2CW(szText), cchMax);
		}
		else
		{
			// 使用 ANSI 字符串拷贝API 来返回帮助字符串. 
			lstrcpynA(pszName, T2CA(szText), cchMax);
		}
		return S_OK;
	}
	return E_INVALIDARG;
}

HRESULT CUPDFContextMenu::InvokeCommand(LPCMINVOKECOMMANDINFO pCmdInfo)
{
	// 如果lpVerb 实际指向一个字符串, 忽略此次调用并退出.
	if (0 != HIWORD(pCmdInfo->lpVerb))
		return E_INVALIDARG;
	std::wstring installPath = ReadReg(HKEY_CURRENT_USER, _T("Software\\UPDF"), _T("InstallPath"));
	std::wstring exePath = installPath + _T("\\UPDF.exe");
	if (m_FileType == PDF) {
		if (m_filePathVector.size() > 1) { // 多文件
			switch (LOWORD(pCmdInfo->lpVerb))
			{
			case 0:
			{   // UPDFShell://Edit{ data:[{path:""},{path:""}] }
				std::string dataStr = "";
				for (int i = 0; i < m_filePathVector.size(); ++i) {
					dataStr += "{";
					dataStr += getKeyValue("path", UnicodeToAnsi(m_filePathVector.at(i).c_str()).c_str());
					dataStr += "},";
				}
				dataStr = dataStr.substr(0, dataStr.length() - 1);
				std::string dataArrStr = getKeyValueArray("data", dataStr);

				std::string jsonStr = "{" + dataArrStr + "}";
				std::string prefixStr = "UPDFShell://Edit";
				std::string param = prefixStr + jsonStr;
				WCHAR szMsg[MAX_PATH * 5];
				wsprintf(szMsg, _T("json:\n\n%s"), UTF8ToUnicode(param.c_str()).c_str());
				MessageBox(pCmdInfo->hwnd, szMsg, _T("SimpleShlExt"),
					MB_ICONINFORMATION);
				//ShellExecute(NULL, _T("open"), exePath.c_str(), m_filePathVector.at(0).c_str(), installPath.c_str(), SW_SHOWNORMAL);
				return S_OK;
			}
			break;
			default:
				return E_INVALIDARG;
				break;
			}
		}
		else {
			switch (LOWORD(pCmdInfo->lpVerb))
			{
			case 0:
			{
				ShellExecute(NULL, _T("open"), exePath.c_str(), m_filePathVector.at(0).c_str(), installPath.c_str(), SW_SHOWNORMAL);
				return S_OK;
			}
			case 1:
			{
				WCHAR szMsg[MAX_PATH + 32];
				wsprintf(szMsg, _T("print:\n\n%s"), m_filePathVector.at(0).c_str());
				MessageBox(pCmdInfo->hwnd, szMsg, _T("SimpleShlExt"),
					MB_ICONINFORMATION);
				return S_OK;
			}
			break;
			default:
				return E_INVALIDARG;
				break;
			}
		}
	}
	else if (m_FileType == Document || m_FileType == Image) {
		switch (LOWORD(pCmdInfo->lpVerb))
		{
		case 0:
		{
			WCHAR szMsg[MAX_PATH + 32];
			wsprintf(szMsg, _T("convert:\n\n%s"), m_filePathVector.at(0).c_str());
			MessageBox(pCmdInfo->hwnd, szMsg, _T("SimpleShlExt"),
				MB_ICONINFORMATION);
			return S_OK;
		}
		break;
		default:
			return E_INVALIDARG;
			break;
		}
	}
	return E_INVALIDARG;
}

std::wstring CUPDFContextMenu::getCurrentLanguage()
{
	std::wstring lang = _T("en");
	LCID localeID = GetUserDefaultLCID();
	unsigned short primaryLanguageID = localeID & 0xFF;

	switch (primaryLanguageID)
	{
	case LANG_CHINESE_SIMPLIFIED:
		lang = _T("zh");
		break;
	case LANG_CHINESE_TRADITIONAL:
		lang = _T("zhhk");
		break;
	case LANG_ENGLISH:
		lang = _T("en");
		break;
	case LANG_GERMAN:
		lang = _T("de");
		break;
	case LANG_FRENCH:
		lang = _T("fr");
		break;
	case LANG_ITALIAN:
		lang = _T("it");
		break;
	case LANG_JAPANESE:
		lang = _T("ja");
		break;
	case LANG_PORTUGUESE:
		lang = _T("pt");
		break;
	case LANG_SPANISH:
		lang = _T("es");
		break;
	case LANG_RUSSIAN:
		lang = _T("ru");
		break;
	case LANG_DUTCH:
		lang = _T("nl");
		break;
	case LANG_KOREAN:
		lang = _T("ko");
		break;
	}

	return lang;
}

std::wstring GetString(LPCSTR strSection, LPCSTR szName, LPCSTR iniPath)
{
	char szBuffer[MAX_PATH];
	GetPrivateProfileStringA(strSection, szName, "",
		szBuffer, MAX_PATH, iniPath);
	return UTF8ToUnicode(szBuffer);
}

std::wstring UTF8ToUnicode(const char* strSrc)
{
	std::wstring wstrRet;

	if (NULL != strSrc)
	{
		int len = MultiByteToWideChar(CP_UTF8, 0, strSrc, -1, NULL, 0) * sizeof(WCHAR);
		WCHAR* strDst = new(std::nothrow) WCHAR[len + 1];
		if (NULL != strDst)
		{
			MultiByteToWideChar(CP_UTF8, 0, strSrc, -1, strDst, len);
			wstrRet = strDst;;
			delete[]strDst;
		}
	}

	return wstrRet;
}

std::string UnicodeToAnsi(const WCHAR* strSrc)
{
	std::string strRet;

	if (NULL != strSrc)
	{
		int len = WideCharToMultiByte(CP_ACP, 0, strSrc, -1, NULL, 0, NULL, NULL);
		char* strDst = new(std::nothrow) char[len + 1];
		if (NULL != strDst)
		{
			WideCharToMultiByte(CP_ACP, 0, strSrc, -1, strDst, len, NULL, NULL);
			strRet = strDst;
			delete[]strDst;
		}
	}

	return strRet;
}

std::string UTF8ToAnsi(const char* strSrc)
{
	return UnicodeToAnsi(UTF8ToUnicode(strSrc).c_str());
}

std::wstring ReadReg(HKEY key, LPCWSTR subPath, LPCWSTR subKey)
{
	std::wstring value = _T("");
	HKEY hKey;
	if (ERROR_SUCCESS == RegOpenKeyEx(key, subPath, 0, KEY_READ, &hKey)) {

		DWORD dwSize = 0;
		DWORD dwDataType = 0;
		RegQueryValueEx(hKey, subKey, 0, &dwDataType, NULL, &dwSize);
		WCHAR* lpValue = new WCHAR[dwSize];
		memset(lpValue, 0, dwSize * sizeof(BYTE));
		RegQueryValueEx(hKey, subKey, 0, &dwDataType, (LPBYTE)lpValue, &dwSize);
		RegCloseKey(hKey);
		value = std::wstring(lpValue);
		delete[] lpValue;
	}
	return value;
}

/**
 * 拼接int
 */
std::string getKeyValue(std::string sKey, int iValue)
{
	char szDoubleQutoes[] = "\"";
	char szColon[] = ":";
	char szValue[50] = { 0 };
	std::string strResult;
	strResult.append(szDoubleQutoes);
	strResult.append(sKey);
	strResult.append(szDoubleQutoes);
	strResult.append(szColon);
	sprintf(szValue, "%d", iValue);
	strResult.append(szValue);
	return strResult;
}
/**
 * 拼接float，保留3位
 */
std::string getKeyValue(std::string sKey, float fValue)
{
	char szDoubleQutoes[] = "\"";
	char szColon[] = ":";
	char szValue[50] = { 0 };

	std::string strResult;

	strResult.append(szDoubleQutoes);
	strResult.append(sKey);
	strResult.append(szDoubleQutoes);

	strResult.append(szColon);
	sprintf(szValue, "%0.3f", fValue);
	strResult.append(szValue);

	return strResult;
}

/**
 * 拼接string
 */
std::string getKeyValue(std::string sKey, std::string sValue)
{
	char szDoubleQutoes[] = "\"";
	char szColon[] = ":";
	std::string strResult;
	strResult.append(szDoubleQutoes);
	strResult.append(sKey);
	strResult.append(szDoubleQutoes);
	strResult.append(szColon);
	strResult.append(szDoubleQutoes);
	strResult.append(sValue);
	strResult.append(szDoubleQutoes);
	return strResult;
}

/**
 * 拼接array
 */
std::string getKeyValueArray(std::string sKey, std::string sArray)
{
	char szDoubleQutoes[] = "\"";
	char szColon[] = ":";
	std::string strResult;
	strResult.append(szDoubleQutoes);
	strResult.append(sKey);
	strResult.append(szDoubleQutoes);
	strResult.append(szColon);
	strResult.append("[");
	strResult.append(sArray);
	strResult.append("]");
	return strResult;
}
