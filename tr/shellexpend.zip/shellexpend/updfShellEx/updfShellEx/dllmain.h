﻿// dllmain.h: 模块类的声明。

class CupdfShellExModule : public ATL::CAtlDllModuleT< CupdfShellExModule >
{
public :
	DECLARE_LIBID(LIBID_updfShellExLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_UPDFSHELLEX, "{2d5e41f1-74f0-4f3a-bc10-1c3f319d17d4}")
};

extern class CupdfShellExModule _AtlModule;
