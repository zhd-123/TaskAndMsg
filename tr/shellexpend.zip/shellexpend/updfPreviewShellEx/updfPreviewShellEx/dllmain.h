﻿// dllmain.h: 模块类的声明。

class CupdfPreviewShellExModule : public ATL::CAtlDllModuleT< CupdfPreviewShellExModule >
{
public :
	DECLARE_LIBID(LIBID_updfPreviewShellExLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_UPDFPREVIEWSHELLEX, "{0c453996-ec72-42bf-9ce9-0f8b3fd9ce85}")
};

extern class CupdfPreviewShellExModule _AtlModule;
