﻿// PDFPreviewHandler.cpp: CPDFPreviewHandler 的实现

#include "pch.h"
#include "PDFPreviewHandler.h"
#include <Shlwapi.h>
#include <assert.h>
#include <WindowsX.h>
#include <richedit.h>   // MSFTEDIT_CLASS

 
extern HINSTANCE   g_hInst;
#pragma comment(lib, "Shlwapi.lib")
template <class T> void SafeRelease(T **ppT)
{
	if (*ppT)
	{
		(*ppT)->Release();
		*ppT = NULL;
	}
}
inline int RECTWIDTH(const RECT &rc)
{
	return (rc.right - rc.left);
}

inline int RECTHEIGHT(const RECT &rc)
{
	return (rc.bottom - rc.top);
}

void reLocateElement(HWND hWnd, int width, int height)
{
	int bottomBarHeight = 32;
	int iconHeight = 24;
	HWND hPctbox = GetDlgItem(hWnd, IDC_STATIC_PICTURE);
	SetWindowPos(hPctbox, NULL, 0, 0, width, height - bottomBarHeight,
		SWP_NOZORDER | SWP_NOACTIVATE);

	HWND hBtnUp = GetDlgItem(hWnd, IDC_BUTTON_UP);
	SetWindowPos(hBtnUp, NULL, 10, height - iconHeight,
		iconHeight, iconHeight, SWP_NOZORDER | SWP_NOACTIVATE);
	HWND hBtnDown = GetDlgItem(hWnd, IDC_BUTTON_DOWN);
	SetWindowPos(hBtnDown, NULL, 30 + iconHeight, height - iconHeight,
		iconHeight, iconHeight, SWP_NOZORDER | SWP_NOACTIVATE);
	HWND hLabelPages = GetDlgItem(hWnd, IDC_STATIC_PAGES);

	int textWidth = 100;
	SetWindowPos(hLabelPages, NULL, width - textWidth - 10, height - iconHeight,
		textWidth, iconHeight, SWP_NOZORDER | SWP_NOACTIVATE);
}
// CPDFPreviewHandler

IFACEMETHODIMP CPDFPreviewHandler::Initialize(IStream *pStream, DWORD grfMode)
{
	HRESULT hr = E_INVALIDARG;

	if (pStream)
	{
		// Initialize can be called more than once, so release existing valid m_pStream.
		if (m_pStream)
		{
			m_pStream->Release();
			m_pStream = NULL;
		}

		m_pStream = pStream;
		m_pStream->AddRef();
		hr = S_OK;
	}
	return hr;
}

// This method gets called when the previewer gets created. It sets the parent 
// window of the previewer window, as well as the area within the parent to be 
// used for the previewer window.
IFACEMETHODIMP CPDFPreviewHandler::SetWindow(HWND hwnd, const RECT *prc)
{
	if (hwnd && prc)
	{
		m_hwndParent = hwnd;  // Cache the HWND for later use
		m_rcParent = *prc;    // Cache the RECT for later use

		if (m_hwndPreview)
		{
			// Update preview window parent and rect information
			SetParent(m_hwndPreview, m_hwndParent);
			int width = RECTWIDTH(m_rcParent);
			int height = RECTHEIGHT(m_rcParent);
			SetWindowPos(m_hwndPreview, NULL, m_rcParent.left, m_rcParent.top,
				width, height, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
		}
	}
	return S_OK;
}

// Directs the preview handler to set focus to itself.
IFACEMETHODIMP CPDFPreviewHandler::SetFocus()
{
	HRESULT hr = S_FALSE;
	if (m_hwndPreview)
	{
		::SetFocus(m_hwndPreview);
		hr = S_OK;
	}
	return hr;
}

// Directs the preview handler to return the HWND from calling the GetFocus 
// function.
IFACEMETHODIMP CPDFPreviewHandler::QueryFocus(HWND *phwnd)
{
	HRESULT hr = E_INVALIDARG;
	if (phwnd)
	{
		*phwnd = ::GetFocus();
		if (*phwnd)
		{
			hr = S_OK;
		}
		else
		{
			hr = HRESULT_FROM_WIN32(GetLastError());
		}
	}
	return hr;
}

// Directs the preview handler to handle a keystroke passed up from the 
// message pump of the process in which the preview handler is running.
HRESULT CPDFPreviewHandler::TranslateAccelerator(MSG *pmsg)
{
	HRESULT hr = S_FALSE;
	IPreviewHandlerFrame *pFrame = NULL;
	if (m_punkSite && SUCCEEDED(m_punkSite->QueryInterface(&pFrame)))
	{
		// If your previewer has multiple tab stops, you will need to do 
		// appropriate first/last child checking. This sample previewer has 
		// no tabstops, so we want to just forward this message out.
		hr = pFrame->TranslateAccelerator(pmsg);

		pFrame->Release();
	}
	return hr;
}

// This method gets called when the size of the previewer window changes 
// (user resizes the Reading Pane). It directs the preview handler to change 
// the area within the parent hwnd that it draws into.
IFACEMETHODIMP CPDFPreviewHandler::SetRect(const RECT *prc)
{
	HRESULT hr = E_INVALIDARG;
	if (prc != NULL)
	{
		m_rcParent = *prc;
		if (m_hwndPreview)
		{
			// Preview window is already created, so set its size and position.
			int width = m_rcParent.right - m_rcParent.left;
			int height = m_rcParent.bottom - m_rcParent.top;
			SetWindowPos(m_hwndPreview, NULL, m_rcParent.left, m_rcParent.top,
				width, // Width
				height, // Height
				SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
		}
		hr = S_OK;
	}
	return hr;
}

// The method directs the preview handler to load data from the source 
// specified in an earlier Initialize method call, and to begin rendering to 
// the previewer window.
IFACEMETHODIMP CPDFPreviewHandler::DoPreview()
{
	// Cannot call more than once.
	// (Unload should be called before another DoPreview)
	if (m_hwndPreview != NULL || !m_pStream)
	{
		return E_FAIL;
	}

	HRESULT hr = E_FAIL;
	HBITMAP hRecipeImage = NULL;

	//CreatePageHBitmap(m_pStream, &hRecipeImage);
	// Create the preview window.
	hr = CreatePreviewWindow(hRecipeImage);
	if (FAILED(hr))
	{
		goto Cleanup;
	}

Cleanup:
	// Clean up the allocated resources in a centralized place.
	if (hRecipeImage)
	{
		DeleteObject(hRecipeImage);
		hRecipeImage = NULL;
	}

	return hr;
}

// This method gets called when a shell item is de-selected. It directs the 
// preview handler to cease rendering a preview and to release all resources 
// that have been allocated based on the item passed in during the 
// initialization.
HRESULT CPDFPreviewHandler::Unload()
{
	if (m_pStream)
	{
		m_pStream->Release();
		m_pStream = NULL;
	}

	if (m_hwndPreview)
	{
		DestroyWindow(m_hwndPreview);
		m_hwndPreview = NULL;
	}

	return S_OK;
}

// Retrieves a handle to one of the windows participating in in-place 
// activation (frame, document, parent, or in-place object window).
IFACEMETHODIMP CPDFPreviewHandler::GetWindow(HWND *phwnd)
{
	HRESULT hr = E_INVALIDARG;
	if (phwnd)
	{
		*phwnd = m_hwndParent;
		hr = S_OK;
	}
	return hr;
}

// Determines whether context-sensitive help mode should be entered during an 
// in-place activation session
IFACEMETHODIMP CPDFPreviewHandler::ContextSensitiveHelp(BOOL fEnterMode)
{
	return E_NOTIMPL;
}

// IObjectWithSite methods
HRESULT CPDFPreviewHandler::SetSite(IUnknown *punkSite)
{
	SafeRelease(&m_punkSite);
	return punkSite ? punkSite->QueryInterface(&m_punkSite) : S_OK;
}

HRESULT CPDFPreviewHandler::GetSite(REFIID riid, void **ppv)
{
	*ppv = NULL;
	return m_punkSite ? m_punkSite->QueryInterface(riid, ppv) : E_FAIL;
}

INT_PTR CALLBACK DialogProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	switch (Msg)
	{
		case WM_PAINT:
		{
			RECT rc;
			PAINTSTRUCT ps;
			HDC hdc = BeginPaint(hWnd, &ps);   // prepares the specified window for painting
			HBRUSH hcolor = CreateSolidBrush(RGB(255, 255, 255));
			HGDIOBJ holdbrush = SelectObject(hdc, hcolor); // select the brush we want (hbrush) and store the previous brush holdbrush
			GetClientRect(hWnd, &rc);  //retrieves the coordinates of the window's client area.
			FillRect(hdc, &rc, hcolor); //uses the new brush
			//for fun  DrawText(hdc,"DrawText: hello world",-1,&rc,DT_SINGLELINE | DT_CENTER | DT_VCENTER); 
			//draw text in the rectangle
			EndPaint(hWnd, &ps);  // marks the end of painting in the specified window.
			long retval = (long)SelectObject(hdc, holdbrush);  // select old brush
			bool tbool = DeleteObject(hcolor);  //destroy the new brush else gdi count grows
			return 0L;//says we processed the message
		}
		break;
		case WM_SIZE:
		{
			int width = LOWORD(lParam);
			int height = HIWORD(lParam);
			reLocateElement(hWnd, width, height);
		}
		break;
		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
			case IDOK:
				// ...
				break;
			case IDCANCEL:
				// ...
				break;
			case WM_CTLCOLORSTATIC:
			{
				HDC hDC = (HDC)wParam;
				HWND hPageWnd = (HWND)lParam;
				//SetBkMode((HDC)wParam, TRANSPARENT);
				if (hPageWnd == GetDlgItem(hWnd, IDC_STATIC_PAGES))
				{
					////获取客户区坐标
					//RECT rcRect;
					//GetClientRect(hPageWnd, &rcRect);

					////填充背景色
					//HBRUSH hBkBrush = CreateSolidBrush(RGB(100, 255, 255));
					//FillRect(hDC, &rcRect, hBkBrush);
					//DeleteObject(hBkBrush);

					//设置字体颜色
					SetTextColor(hDC, RGB(255, 0, 0));

					//背景透明
					SetBkMode(hDC, TRANSPARENT);

					//返回空画刷
					//return (BOOL)CreateSolidBrush(GetSysColor(COLOR_MENU));
				}
			}
			break;
			}
			break;
	}
	return DefWindowProc(hWnd, Msg, wParam, lParam);
}
// Create the preview window based on the recipe information.
HRESULT CPDFPreviewHandler::CreatePreviewWindow(HBITMAP pageImage)
{
	assert(m_hwndPreview == NULL);
	assert(m_hwndParent != NULL);

	//WCHAR szMsg[64];
	//wsprintf(szMsg, _T("CreatePreviewWindow"));
	//MessageBox(NULL, szMsg, _T("SimpleShlExt"),
	//	MB_ICONINFORMATION);
	HRESULT hr = S_OK;
	m_hwndPreview = CreateDialog(g_hInst, MAKEINTRESOURCE(IDD_MAINDIALOG),
		m_hwndParent, DialogProc);
	if (m_hwndPreview == NULL)
	{
		hr = HRESULT_FROM_WIN32(GetLastError());
	}

	if (SUCCEEDED(hr))
	{
		// Set the preview window position.
		int width = RECTWIDTH(m_rcParent);
		int height = RECTHEIGHT(m_rcParent);
		SetWindowPos(m_hwndPreview, NULL, m_rcParent.left, m_rcParent.top,
			width, height, SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE);
		// Set the title label on the window.
		HWND hLabelPages = GetDlgItem(m_hwndPreview, IDC_STATIC_PAGES);
		Static_SetText(hLabelPages, _T("23"));
		

		HWND hBtnUp = GetDlgItem(m_hwndPreview, IDC_BUTTON_UP);
		//Static_SetIcon(hBtnUp, LoadIcon(g_hInst, MAKEINTRESOURCE(IDI_ICON_UP)));
		SendMessage(hBtnUp, STM_SETICON, (WPARAM)IMAGE_ICON, (LPARAM)hBtnUp);


		HWND hBtnDown = GetDlgItem(m_hwndPreview, IDC_BUTTON_DOWN);
		Static_SetIcon(hBtnDown, LoadIcon(g_hInst, MAKEINTRESOURCE(IDI_ICON_DOWN)));

		HWND hPctbox = GetDlgItem(m_hwndPreview, IDC_STATIC_PICTURE);
		pageImage = LoadBitmap(g_hInst, MAKEINTRESOURCE(IDB_BITMAP1));
		SendMessage(hPctbox, STM_SETIMAGE, IMAGE_BITMAP, reinterpret_cast<LPARAM>(pageImage));

		// Show the preview window.
		ShowWindow(m_hwndPreview, SW_SHOW);
	}
	return hr;
}

IStream* CPDFPreviewHandler::stream()
{
	return m_pStream;
}

int GetPDFBlock(void* param, unsigned long position,
	unsigned char* pBuf, unsigned long size)
{
	CPDFPreviewHandler *pInst = (CPDFPreviewHandler*)param;
	IStream *pstm = pInst->stream();
	if (!pInst || !pstm) {
		return 0;
	}

	LARGE_INTEGER lagerInterger = {0};
	lagerInterger.QuadPart = position;
	lagerInterger.LowPart = position & 0xFFFFFFFF;
	lagerInterger.HighPart = (position >> 32) & 0xFFFFFFFF;
	ULARGE_INTEGER outUlagerInterger;
	pstm->Seek(lagerInterger, STREAM_SEEK_SET, &outUlagerInterger);
	unsigned long readLen;
	pstm->Read(pBuf, size, &readLen);
	return readLen;
}

HRESULT CPDFPreviewHandler::CreatePageHBitmap(IStream *pstm, HBITMAP *phbmp)
{
	WCHAR szMsg[64];
	wsprintf(szMsg, _T("CreatePageHBitmap"));
	MessageBox(NULL, szMsg, _T("SimpleShlExt"),
		MB_ICONINFORMATION);
	HRESULT hr = S_OK;

	PDF_FILEACCESS pFileAccess;
	STATSTG pstatstg;
	pstm->Stat(&pstatstg, STATFLAG_DEFAULT);
	pFileAccess.m_FileLen = pstatstg.cbSize.QuadPart;
	pFileAccess.m_Param = this;
	pFileAccess.m_GetBlock = GetPDFBlock;

	PDF_DOCUMENT pdfDoc = PDF_LoadCustomDocument(&pFileAccess, "");
	if (!pdfDoc) {
		return S_FALSE;
	}
	int pageCount = PDF_GetPageCount(pdfDoc);
	if (pageCount <= 0) {
		return S_FALSE;
	}

	int pageIndex = 1;
	PDF_PAGE pdfPage = PDF_LoadPage(pdfDoc, pageIndex);
	if (!pdfPage) {
		return S_FALSE;
	}
	int flags = PDF_REVERSE_BYTE_ORDER | PDF_ANNOT | PDF_SHOW_WIDGET;
	int pageWidth = PDF_GetPageWidth(pdfPage);
	int pageHeight = PDF_GetPageHeight(pdfPage);
	PDF_BITMAP bitmap = PDFBitmap_Create(pageWidth * 4, pageHeight, 1);
	PDF_RenderPageRectToBitmap(pdfPage, bitmap, 0, 0, pageWidth,
		pageHeight, flags);
	int stride = PDFBitmap_GetStride(bitmap);
	int width = PDFBitmap_GetWidth(bitmap);
	int height = PDFBitmap_GetHeight(bitmap);

	unsigned char *buffer = new unsigned char(stride * height + 16);
	buffer = (unsigned char *)PDFBitmap_GetBuffer(bitmap);

	BITMAPINFO bmi;
	ZeroMemory(&bmi, sizeof(BITMAPINFO));
	bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biHeight = width;
	bmi.bmiHeader.biWidth = height;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biCompression = BI_RGB;
	HDC dc = CreateCompatibleDC(NULL);
	*phbmp = CreateDIBSection(dc, &bmi, DIB_RGB_COLORS, (void**)&buffer, NULL, 0);

	PDFBitmap_Destroy(bitmap);
	PDF_ClosePage(pdfPage);
	PDF_CloseDocument(pdfDoc);
	return hr;
}