﻿// updfPreviewShellEx.cpp: DLL 导出的实现。

//
// 注意:  COM+ 1.0 信息: 
//      请记住运行 Microsoft Transaction Explorer 以安装组件。
//      默认情况下不进行注册。

#include "pch.h"
#include "framework.h"
#include "resource.h"
#include "updfPreviewShellEx_i.h"
#include "dllmain.h"

#pragma warning(disable: 4996)
using namespace ATL;


// 用于确定 DLL 是否可由 OLE 卸载。
_Use_decl_annotations_
STDAPI DllCanUnloadNow(void)
{
	return _AtlModule.DllCanUnloadNow();
}

// 返回一个类工厂以创建所请求类型的对象。
_Use_decl_annotations_
STDAPI DllGetClassObject(_In_ REFCLSID rclsid, _In_ REFIID riid, _Outptr_ LPVOID* ppv)
{
	return _AtlModule.DllGetClassObject(rclsid, riid, ppv);
}

// DllRegisterServer - 向系统注册表中添加项。
_Use_decl_annotations_
STDAPI DllRegisterServer(void)
{
	// 注册对象、类型库和类型库中的所有接口
	if (0 == (GetVersion() & 0x80000000UL))
	{
		CRegKey reg;
		LONG    lRet;

		lRet = reg.Open(HKEY_CLASSES_ROOT,
			_T(".pdf\\ShellEx\\{8895b1c6-b41f-4c1c-a562-0d564250836f}"),
			KEY_SET_VALUE);

		if (ERROR_SUCCESS != lRet)
			return E_ACCESSDENIED;

		lRet = reg.SetStringValue(NULL, _T("{017bb831-7821-4747-8ab1-b4425023c797}"));
		if (ERROR_SUCCESS != lRet)
			return E_ACCESSDENIED;

		lRet = reg.Open(HKEY_LOCAL_MACHINE,
			_T("Software\\Microsoft\\Windows\\CurrentVersion\\PreviewHandlers"));

		if (ERROR_SUCCESS != lRet)
			return E_ACCESSDENIED;

		lRet = reg.SetStringValue(_T("{017bb831-7821-4747-8ab1-b4425023c797}"), _T("UPDF.PreviewHandler"));
		if (ERROR_SUCCESS != lRet)
			return E_ACCESSDENIED;

		lRet = reg.Create(HKEY_CLASSES_ROOT, _T("UPDF.PreviewHandler\\CLSID"));
		if (ERROR_SUCCESS != lRet)
			return E_ACCESSDENIED;
		lRet = reg.SetStringValue(NULL, _T("{017bb831-7821-4747-8ab1-b4425023c797}"));
		if (ERROR_SUCCESS != lRet)
			return E_ACCESSDENIED;
	}
	HRESULT hr = _AtlModule.DllRegisterServer();
	return hr;
}

// DllUnregisterServer - 移除系统注册表中的项。
_Use_decl_annotations_
STDAPI DllUnregisterServer(void)
{
	if (0 == (GetVersion() & 0x80000000UL))
	{
		CRegKey reg;
		LONG    lRet;

		lRet = reg.Open(HKEY_CLASSES_ROOT,
			_T(".pdf\\ShellEx\\{8895b1c6-b41f-4c1c-a562-0d564250836f}"),
			KEY_SET_VALUE);

		if (ERROR_SUCCESS != lRet)
			return E_ACCESSDENIED;

		lRet = reg.SetStringValue(NULL, _T(""));
		if (ERROR_SUCCESS != lRet)
			return E_ACCESSDENIED;
		lRet = RegDeleteKeyW(HKEY_LOCAL_MACHINE, _T("\\{017bb831-7821-4747-8ab1-b4425023c797}"));

		lRet = reg.Open(HKEY_LOCAL_MACHINE,
			_T("Software\\Microsoft\\Windows\\CurrentVersion\\PreviewHandlers"),
			KEY_SET_VALUE);

		if (ERROR_SUCCESS == lRet)
		{
			lRet = reg.DeleteValue(_T("{017bb831-7821-4747-8ab1-b4425023c797}"));
		}
		lRet = RegDeleteKeyW(HKEY_CLASSES_ROOT, _T("UPDF.PreviewHandler\\CLSID"));
	}
	HRESULT hr = _AtlModule.DllUnregisterServer();
	return hr;
}

// DllInstall - 按用户和计算机在系统注册表中逐一添加/移除项。
STDAPI DllInstall(BOOL bInstall, _In_opt_  LPCWSTR pszCmdLine)
{
	HRESULT hr = E_FAIL;
	static const wchar_t szUserSwitch[] = L"user";

	if (pszCmdLine != nullptr)
	{
		if (_wcsnicmp(pszCmdLine, szUserSwitch, _countof(szUserSwitch)) == 0)
		{
			ATL::AtlSetPerUserRegistration(true);
		}
	}

	if (bInstall)
	{
		hr = DllRegisterServer();
		if (FAILED(hr))
		{
			DllUnregisterServer();
		}
	}
	else
	{
		hr = DllUnregisterServer();
	}

	return hr;
}


