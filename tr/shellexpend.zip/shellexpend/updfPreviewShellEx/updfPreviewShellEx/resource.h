﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 updfPreviewShellEx.rc 使用
//
#define IDD_MAINDIALOG                  9
#define IDS_PROJNAME                    100
#define IDR_UPDFPREVIEWSHELLEX          101
#define IDS_STRING101                   101
#define IDR_PDFPREVIEWHANDLER           106
#define IDB_BITMAP1                     201
#define IDC_STATIC_PAGES                201
#define IDC_BUTTON_UP                   202
#define IDC_BUTTON_DOWN                 203
#define IDC_STATIC_PICTURE              204
#define IDI_ICON_UP                     206
#define IDI_ICON2                       207
#define IDI_ICON_DOWN                   207

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        208
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         205
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
